const STORAGE_KEY = "webnotes_notes";

function pad2(n){ return String(n).padStart(2,"0"); }
function dateKeyFromTs(ts){
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`;
}
function timeLabel(ts){
  const d = new Date(ts);
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}
function monthName(m){ return ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][m]; }
// 显示吐司消息
function toast(msg){
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => (t.hidden = true), 1600);
}
// 读取和写入笔记数据
async function getNotes(){
  const data = await chrome.storage.local.get({[STORAGE_KEY]: []});
  return Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
}
async function setNotes(notes){
  await chrome.storage.local.set({[STORAGE_KEY]: notes});
}
// URL 规范化（去除 hash 部分）
function normalizeUrl(u){
  try{ const url = new URL(u); url.hash=""; return url.toString(); }
  catch{ return u; }
}

function buildJumpUrl(urlStr, noteId){
  try{
    const u = new URL(urlStr);
    u.searchParams.set("__webnotes_jump", noteId);
    return u.toString();
  }catch{
    return urlStr;
  }
}


function hostFromUrl(u){
  try{ return new URL(u).hostname || ""; }catch{ return ""; }
}

// 哈希字符串为无符号整数
function hashStr(s){
  // simple deterministic hash (djb2)
  let h = 5381;
  for (let i = 0; i < s.length; i++){
    h = ((h << 5) + h) + s.charCodeAt(i);
    h = h >>> 0;
  }
  return h;
}
function toneFromUrl(u){
  // 0=blue(default), 1=green, 2=yellow
  const host = hostFromUrl(u) || String(u || "");
  const h = hashStr(host.toLowerCase());
  return h % 3;
}


function computeSites(notes){
  const hosts = new Set();
  for (const n of notes){
    const h = hostFromUrl(n.url);
    if (h) hosts.add(h);
  }
  return Array.from(hosts).sort((a,b)=>a.localeCompare(b));
}
// 渲染站点选择下拉框
function renderSiteSelect(sites){
  const sel = document.getElementById("siteSelect");
  if (!sel) return;
  const opts = [`<option value="all">All sites</option>`]
    .concat(sites.map(h => `<option value="${h}">${h}</option>`));
  sel.innerHTML = opts.join("");
  if (![...sel.options].some(o => o.value === state.site)) state.site = "all";
  sel.value = state.site;
}
// 检查笔记是否匹配当前站点过滤器
function matchesSite(note){
  if (state.site === "all") return true;
  return hostFromUrl(note.url) === state.site;
}


let state = {
  notes: [],
  year: new Date().getFullYear(),
  site: "all",           // hostname filter
  activeDateKey: null,   // YYYY-MM-DD
  query: "",
  sort: "new",
};
// 计算所有笔记涉及的年份列表
function computeYears(notes){
  const years = new Set();
  for (const n of notes) years.add(new Date(n.createdAt).getFullYear());
  years.add(new Date().getFullYear());
  return Array.from(years).sort((a,b)=>b-a);
}
// 按日期统计笔记数量
function countByDateKey(notes, year){
  const map = new Map();
  for (const n of notes){
    const d = new Date(n.createdAt);
    if (d.getFullYear() !== year) continue;
    const k = dateKeyFromTs(n.createdAt);
    map.set(k, (map.get(k) || 0) + 1);
  }
  return map;
}

function heatLevel(c){
  if (!c) return 0;
  if (c === 1) return 1;
  if (c <= 3) return 2;
  return 3;
}
// 渲染年份选择下拉框
function renderYearSelect(years){
  const sel = document.getElementById("yearSelect");
  sel.innerHTML = years.map(y => `<option value="${y}">${y}</option>`).join("");
  sel.value = String(state.year);
  sel.onchange = () => {
    state.year = parseInt(sel.value,10);
    state.activeDateKey = null;
    render();
  };
}
// 创建热力图单元格元素
function createCell(dateKey, level, isActive, title){
  const div = document.createElement("div");
  div.className = "cell" + (level ? "" : "") + (isActive ? " cell--active" : "");
  if (level === 0) div.style.background = "var(--h0)";
  if (level === 1) div.style.background = "var(--h1)";
  if (level === 2) div.style.background = "var(--h2)";
  if (level === 3) div.style.background = "var(--h3)";
  div.title = title;
  div.dataset.dateKey = dateKey;
  div.onclick = () => {
    if (!dateKey) return;
    state.activeDateKey = (state.activeDateKey === dateKey) ? null : dateKey;
    render();
    // smooth jump to that day group if exists
    if (state.activeDateKey){
      const el = document.querySelector(`[data-day-header="${state.activeDateKey}"]`);
      if (el) el.scrollIntoView({behavior:"smooth", block:"start"});
    }
  };
  return div;
}
// 渲染热力图
function renderHeatmap(){
  const heatmap = document.getElementById("heatmap");
  heatmap.innerHTML = "";
  const counts = countByDateKey(state.notes.filter(matchesSite), state.year);

  for (let m=0; m<12; m++){
    const month = document.createElement("div");
    month.className = "month";
    const head = document.createElement("div");
    head.className = "month__title";
    head.innerHTML = `<span>${monthName(m)}</span><span style="font-weight:800;color:#111827">${state.year}</span>`;
    month.appendChild(head);

    const grid = document.createElement("div");
    grid.className = "grid";

    const first = new Date(state.year, m, 1);
    const startDay = first.getDay(); // 0 Sun
    const daysInMonth = new Date(state.year, m+1, 0).getDate();

    // empty padding
    for (let i=0; i<startDay; i++){
      const e = document.createElement("div");
      e.className = "cell cell--empty";
      grid.appendChild(e);
    }

    for (let d=1; d<=daysInMonth; d++){
      const dk = `${state.year}-${pad2(m+1)}-${pad2(d)}`;
      const c = counts.get(dk) || 0;
      const level = heatLevel(c);
      const title = `${dk} · ${c} note${c===1?"":"s"}`;
      const cell = createCell(dk, level, state.activeDateKey === dk, title);
      grid.appendChild(cell);
    }

    month.appendChild(grid);
    heatmap.appendChild(month);
  }
}
// 检查笔记是否匹配当前搜索查询
function matchesQuery(note){
  const q = state.query.trim().toLowerCase();
  if (!q) return true;
  const hay = [
    note.title ?? "",
    note.quote ?? "",
    note.comment ?? "",
    note.url ?? ""
  ].join("\n").toLowerCase();
  return hay.includes(q);
}
// 过滤笔记列表
function filteredNotes(){
  let arr = state.notes.filter(n => new Date(n.createdAt).getFullYear() === state.year).filter(matchesSite);
  if (state.activeDateKey) arr = arr.filter(n => dateKeyFromTs(n.createdAt) === state.activeDateKey);
  arr = arr.filter(matchesQuery);

  arr.sort((a,b) => state.sort === "new" ? (b.createdAt - a.createdAt) : (a.createdAt - b.createdAt));
  return arr;
}
// 按日期分组笔记
function groupByDate(arr){
  const groups = new Map();
  for (const n of arr){
    const k = dateKeyFromTs(n.createdAt);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(n);
  }
  // sort groups by date desc
  const keys = Array.from(groups.keys()).sort((a,b)=> state.sort === "new" ? (b.localeCompare(a)) : (a.localeCompare(b)));
  return keys.map(k => ({ dateKey: k, items: groups.get(k) }));
}
// 防抖函数
function debounce(fn, ms){
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

// ----------------------------
// 数据保存优化
// ----------------------------
// 问题：直接在每次编辑时写入存储会触发 storage.onChanged 事件，
// 导致整个笔记列表重新渲染，从而引起输入卡顿。
// 解决方案：
// 1. 将每次编辑的更改缓存在内存中（按笔记 ID 合并）

// 2. 使用防抖函数定期将所有挂起的更改一次性写入存储
// 3. 在写入时，标记此次写入为“我们自己的”，以避免立即重新渲染
let _suppressNextStorageRenderAt = 0;
const _pendingPatches = new Map(); // id -> merged patch (title/comment)

function applyPatchToState(id, patch){
  const idx = state.notes.findIndex(n => n.id === id);
  if (idx === -1) return;
  state.notes[idx] = { ...state.notes[idx], ...patch };
}
// 将挂起的更改写入存储
async function doFlushPendingPatches(){
  if (_pendingPatches.size === 0) return;

  // Read latest, merge patches, write back once.
  const notes = await getNotes();
  const byId = new Map(notes.map(n => [n.id, n]));
  for (const [id, patch] of _pendingPatches.entries()){
    const old = byId.get(id);
    if (!old) continue;
    byId.set(id, { ...old, ...patch });
  }
  _pendingPatches.clear();

  // Mark this write as "ours" so the onChanged listener doesn't re-render immediately.
  _suppressNextStorageRenderAt = Date.now();
  await setNotes(Array.from(byId.values()).sort((a,b)=>b.createdAt-a.createdAt));
}

const scheduleFlushPendingPatches = debounce(doFlushPendingPatches, 800);
// 排队等待写入存储
function queuePersistPatch(id, patch){
  // Update UI state immediately (no re-render)
  applyPatchToState(id, patch);
  // Merge patch for eventual flush
  const cur = _pendingPatches.get(id) || {};
  _pendingPatches.set(id, { ...cur, ...patch });
  scheduleFlushPendingPatches();
}

async function flushNow(){
  // Force flush immediately (used on blur)
  await doFlushPendingPatches();
}

async function deleteNote(id){
  const notes = await getNotes();
  const next = notes.filter(n => n.id !== id);
  await setNotes(next);
  toast("已删除");
}
// 渲染笔记列表
function renderNotes(){
  const list = document.getElementById("notesList");
  const empty = document.getElementById("empty");
  list.innerHTML = "";

  const arr = filteredNotes();
  const groups = groupByDate(arr);

  {
  const totalYear = state.notes.filter(n => new Date(n.createdAt).getFullYear() === state.year).filter(matchesSite).length;
  const siteLabel = state.site === "all" ? "All sites" : state.site;
  const head = state.activeDateKey ? state.activeDateKey : String(state.year);
  document.getElementById("notesMeta").textContent =
    `${head} · ${siteLabel} · ${arr.length}/${totalYear} 条`;
}

  if (arr.length === 0){
    empty.hidden = false;
    return;
  }
  empty.hidden = true;

  let seq = 0; // used to rotate card tones (avoid same color all the time)
  for (const g of groups){
    const header = document.createElement("div");
    header.className = "dayHeader";
    header.dataset.dayHeader = g.dateKey;
    header.innerHTML = `<span>${g.dateKey}</span><span class="dayHeader__meta">${g.items.length} 条</span>`;
    list.appendChild(header);

    for (const n of g.items){
      const card = document.createElement("div");
      // Rotate tones across cards while keeping a stable base per site.
      const tone = (toneFromUrl(n.url) + (seq++ % 3)) % 3;
      card.className = `note note--tone${tone}`;

      const top = document.createElement("div");
      top.className = "note__top";

      const title = document.createElement("input");
      title.className = "note__title";
      title.value = n.title ?? "";
      title.placeholder = "标题（可编辑）";
      title.addEventListener("input", () => queuePersistPatch(n.id, { title: title.value }));
      title.addEventListener("blur", flushNow);
      const meta = document.createElement("div");
      meta.className = "note__meta";

      const site = document.createElement("div");
      site.className = "note__site";
      site.textContent = hostFromUrl(n.url) || "—";

      const time = document.createElement("div");
      time.className = "note__time";
      time.textContent = timeLabel(n.createdAt);

      meta.appendChild(site);
      meta.appendChild(time);

      top.appendChild(title);
      top.appendChild(meta);

      const quote = document.createElement("div");
      quote.className = "note__quote";
      quote.textContent = n.quote ?? "";

      const commentWrap = document.createElement("div");
      commentWrap.className = "note__comment";
      const ta = document.createElement("textarea");
      ta.placeholder = "添加个人注释…";
      ta.value = n.comment ?? "";
      ta.addEventListener("input", () => queuePersistPatch(n.id, { comment: ta.value }));
      ta.addEventListener("blur", flushNow);
      commentWrap.appendChild(ta);

      const bottom = document.createElement("div");
      bottom.className = "note__bottom";

      const url = document.createElement("a");
      url.className = "note__url";
      url.href = n.url;
      url.target = "_blank";
      url.rel = "noreferrer";
      url.textContent = normalizeUrl(n.url);

      const actions = document.createElement("div");
      actions.className = "note__actions";

      const copyBtn = document.createElement("button");
      copyBtn.className = "iconBtn";
      copyBtn.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 8h10v12H8z"/><path d="M6 16H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>复制`;
      copyBtn.onclick = async () => {
        const payload = `${n.title || "Untitled"}
${n.quote || ""}
${n.url}
${new Date(n.createdAt).toLocaleString()}`;
        try{
          await navigator.clipboard.writeText(payload);
          toast("已复制到剪贴板");
        }catch{
          // Fallback
          const ta = document.createElement("textarea");
          ta.value = payload;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand("copy");
          ta.remove();
          toast("已复制到剪贴板");
        }
      };

      const locateBtn = document.createElement("button");
      locateBtn.className = "iconBtn";
      locateBtn.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s7-4.5 7-11a7 7 0 0 0-14 0c0 6.5 7 11 7 11z"/><path d="M12 10.5a1.5 1.5 0 1 0 0 .01z"/></svg>定位`;
      locateBtn.onclick = () => chrome.tabs.create({ url: buildJumpUrl(n.url, n.id) });

      const openBtn = document.createElement("button");
      openBtn.className = "iconBtn";
      openBtn.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 3h7v7"/><path d="M10 14L21 3"/><path d="M21 14v6a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h6"/></svg>打开`;
      openBtn.onclick = () => chrome.tabs.create({ url: n.url });

      const delBtn = document.createElement("button");
      delBtn.className = "iconBtn iconBtn--danger";
      delBtn.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M7 6l1 16h8l1-16"/></svg>删除`;
      delBtn.onclick = async () => {
        if (confirm("确定删除这条笔记？高亮会在页面刷新后自动消失。")) {
          await deleteNote(n.id);
        }
      };

      actions.appendChild(copyBtn);
      actions.appendChild(locateBtn);
      actions.appendChild(openBtn);
      actions.appendChild(delBtn);

      bottom.appendChild(url);
      bottom.appendChild(actions);

      card.appendChild(top);
      card.appendChild(quote);
      card.appendChild(commentWrap);
      card.appendChild(bottom);

      list.appendChild(card);
    }
  }
}
// 渲染整个页面
function render(){
  renderHeatmap();
  renderNotes();

  const clearBtn = document.getElementById("clearFilterBtn");
  clearBtn.disabled = !state.activeDateKey;
  clearBtn.style.opacity = state.activeDateKey ? "1" : ".55";
}
// 导出笔记数据
async function exportJson(){
  const notes = await getNotes();
  const blob = new Blob([JSON.stringify({version:1, exportedAt: Date.now(), notes}, null, 2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `webnotes_export_${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  toast("已导出");
}
// 导入笔记数据
async function importJson(file){
  const txt = await file.text();
  const obj = JSON.parse(txt);
  const incoming = Array.isArray(obj?.notes) ? obj.notes : (Array.isArray(obj) ? obj : []);
  if (!Array.isArray(incoming)) throw new Error("Invalid file");
  // merge by id
  const existing = await getNotes();
  const byId = new Map(existing.map(n => [n.id, n]));
  for (const n of incoming){
    if (!n?.id) continue;
    byId.set(n.id, n);
  }
  await setNotes(Array.from(byId.values()).sort((a,b)=>b.createdAt-a.createdAt));
  toast("已导入");
}
// 初始化页面
async function init(){
  state.notes = await getNotes();

  const years = computeYears(state.notes);
  state.year = years[0] ?? new Date().getFullYear();

  renderYearSelect(years);
  const sites = computeSites(state.notes);
  renderSiteSelect(sites);

  // Restore sidebar state
  const collapsed = localStorage.getItem("webnotes_sidebar_collapsed") === "1";
  document.body.classList.toggle("sidebar-collapsed", collapsed);
  const toggleBtn = document.getElementById("toggleSidebarBtn");
  toggleBtn?.addEventListener("click", ()=>{
    const next = !document.body.classList.contains("sidebar-collapsed");
    document.body.classList.toggle("sidebar-collapsed", next);
    localStorage.setItem("webnotes_sidebar_collapsed", next ? "1" : "0");
  });

  document.getElementById("siteSelect")?.addEventListener("change", (e)=>{
    state.site = e.target.value;
    state.activeDateKey = null; // reset date filter when changing site
    render();
  });


  document.getElementById("searchInput").addEventListener("input", (e)=>{
    state.query = e.target.value;
    renderNotes();
  });

  document.getElementById("sortSelect").addEventListener("change", (e)=>{
    state.sort = e.target.value;
    render();
  });

  document.getElementById("clearFilterBtn").addEventListener("click", ()=>{
    state.activeDateKey = null;
    render();
  });

  document.getElementById("exportBtn").addEventListener("click", exportJson);
  document.getElementById("importBtn").addEventListener("click", ()=>{
    document.getElementById("importFile").click();
  });
  document.getElementById("importFile").addEventListener("change", async (e)=>{
    const f = e.target.files?.[0];
    if (!f) return;
    try{
      await importJson(f);
    }catch(err){
      console.error(err);
      alert("导入失败：文件格式不正确");
    }finally{
      e.target.value = "";
    }
  });

  // 监听存储变化以保持笔记列表同步
  chrome.storage.onChanged.addListener(async (changes, area)=>{
    if (area !== "local") return;
    if (!changes[STORAGE_KEY]) return;
    const active = document.activeElement;
    const isEditing = !!(active && (active.tagName === "TEXTAREA" || active.tagName === "INPUT") && active.closest(".note"));
    const now = Date.now();
    const isOurFlush = (now - _suppressNextStorageRenderAt) < 1200;

    state.notes = await getNotes();

    if (isEditing || isOurFlush) {
      return;
    }

    // 年份列表有变化时刷新年份选择下拉框
    const years = computeYears(state.notes);
    const ySel = document.getElementById("yearSelect");
    const currentOptions = Array.from(ySel.options).map(o => parseInt(o.value,10));
    const needRefresh = years.length !== currentOptions.length || years.some((y,i)=>y !== currentOptions[i]);
    if (needRefresh) renderYearSelect(years);

    // 站点列表有变化时刷新站点选择下拉框
    const sites = computeSites(state.notes);
    renderSiteSelect(sites);

    render();
  });

  render();
}

init();
