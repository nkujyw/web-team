/**
 * Web Notes & Highlighter (Content Script)
 * - 接收来自后台脚本的消息以添加笔记
 * - 在页面上应用高亮
 * - 支持跳转到特定笔记
 * - 监听存储变化以保持高亮同步
 */

const STORAGE_KEY = "webnotes_notes";

// 显示页面上的吐司消息
function showToast(text) {
  try {
    const id = "webnotes-toast";
    let el = document.getElementById(id);
    if (!el) {
      el = document.createElement("div");
      el.id = id;
      el.style.position = "fixed";
      el.style.right = "16px";
      el.style.bottom = "16px";
      el.style.zIndex = "2147483647";
      el.style.padding = "10px 12px";
      el.style.borderRadius = "12px";
      el.style.background = "rgba(17, 24, 39, 0.92)";
      el.style.color = "#fff";
      el.style.fontSize = "12px";
      el.style.fontFamily = "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial";
      el.style.boxShadow = "0 10px 30px rgba(0,0,0,.18)";
      el.style.backdropFilter = "blur(6px)";
      el.style.opacity = "0";
      el.style.transform = "translateY(6px)";
      el.style.transition = "opacity .15s ease, transform .15s ease";
      document.documentElement.appendChild(el);
    }
    el.textContent = text;
    requestAnimationFrame(() => {
      el.style.opacity = "1";
      el.style.transform = "translateY(0)";
    });
    clearTimeout(el.__webnotes_t);
    el.__webnotes_t = setTimeout(() => {
      el.style.opacity = "0";
      el.style.transform = "translateY(6px)";
    }, 1600);
  } catch {}
}

function nowTs() { return Date.now(); }

function pad2(n) { return String(n).padStart(2, "0"); }
function dateKeyFromTs(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function randomId() {
  if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
  return "id_" + Math.random().toString(36).slice(2) + "_" + Date.now().toString(36);
}
// 检查节点是否在排除的标签内
function isExcludedNode(node) {
  if (!node) return true;
  const el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
  if (!el) return true;
  const tag = el.closest("script, style, textarea, input, select, option, code, pre, noscript");
  return !!tag;
}
// 获取文本节点在其父元素中的索引
function getTextNodeIndex(textNode) {
  const parent = textNode.parentNode;
  if (!parent) return -1;
  let idx = 0;
  for (const child of parent.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) {
      if (child === textNode) return idx;
      idx++;
    }
  }
  return -1;
}
// 生成元素的XPath路径
function getXPathForElement(el) {
  if (!el || el.nodeType !== Node.ELEMENT_NODE) return "";
  const parts = [];
  let node = el;
  while (node && node.nodeType === Node.ELEMENT_NODE && node !== document.documentElement) {
    const tag = node.tagName.toLowerCase();
    const siblings = Array.from(node.parentNode?.children ?? []).filter(s => s.tagName === node.tagName);
    const index = siblings.indexOf(node) + 1;
    parts.unshift(`${tag}[${index}]`);
    node = node.parentElement;
  }
  return "/html/" + parts.join("/");
}
// 获取范围的DOM选择器信息
function getDomSelector(range) {
  const startNode = range.startContainer;
  const endNode = range.endContainer;

  const startTextNode = startNode.nodeType === Node.TEXT_NODE ? startNode : null;
  const endTextNode   = endNode.nodeType === Node.TEXT_NODE ? endNode : null;

  const startEl = startTextNode ? startTextNode.parentElement : (startNode.nodeType === Node.ELEMENT_NODE ? startNode : startNode.parentElement);
  const endEl   = endTextNode ? endTextNode.parentElement : (endNode.nodeType === Node.ELEMENT_NODE ? endNode : endNode.parentElement);

  return {
    startXPath: getXPathForElement(startEl),
    startTextIndex: startTextNode ? getTextNodeIndex(startTextNode) : -1,
    startOffset: range.startOffset,

    endXPath: getXPathForElement(endEl),
    endTextIndex: endTextNode ? getTextNodeIndex(endTextNode) : -1,
    endOffset: range.endOffset,

    exact: range.toString().trim(),
    // Lightweight fallback context from start/end text nodes
    startContext: startTextNode?.nodeValue?.slice(Math.max(0, range.startOffset - 30), range.startOffset) ?? "",
    endContext: endTextNode?.nodeValue?.slice(range.endOffset, Math.min((endTextNode?.nodeValue?.length ?? 0), range.endOffset + 30)) ?? "",
  };
}
// 根据XPath和文本节点索引解析出具体的文本节点
function resolveTextNode(xpath, textIndex) {
  if (!xpath) return null;
  const result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
  const el = result.singleNodeValue;
  if (!el || el.nodeType !== Node.ELEMENT_NODE) return null;
  if (textIndex < 0) return null;

  let idx = 0;
  for (const child of el.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) {
      if (idx === textIndex) return child;
      idx++;
    }
  }
  return null;
}
// 将文本节点的指定范围用<mark>标签包裹以实现高亮
function wrapTextSegment(textNode, start, end, noteId) {
  // Split text node and wrap [start, end) with <mark>
  const text = textNode.nodeValue ?? "";
  const len = text.length;
  const s = Math.max(0, Math.min(len, start));
  const e = Math.max(s, Math.min(len, end));
  if (s === e) return null;

  const before = textNode;
  const mid = before.splitText(s);
  const after = mid.splitText(e - s);

  const mark = document.createElement("mark");
  mark.className = "webnotes-mark";
  mark.dataset.webnotesId = noteId;
  mark.textContent = mid.nodeValue ?? "";

  mid.parentNode?.replaceChild(mark, mid);
  return mark;
}
// 在给定范围内高亮所有文本节点
function highlightRange(range, noteId) {
  // Highlight across multiple text nodes in the selection range.
  const root = range.commonAncestorContainer.nodeType === Node.ELEMENT_NODE
    ? range.commonAncestorContainer
    : range.commonAncestorContainer.parentElement;

  if (!root) return [];

  const walker = document.createTreeWalker(
    root,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        if (isExcludedNode(node)) return NodeFilter.FILTER_REJECT;
        // intersectsNode can throw if node is a doctype etc; safe here
        try {
          return range.intersectsNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        } catch {
          return NodeFilter.FILTER_REJECT;
        }
      }
    }
  );

  const textNodes = [];
  let n;
  while ((n = walker.nextNode())) textNodes.push(n);

  const marks = [];
  for (const tn of textNodes) {
    let s = 0;
    let e = (tn.nodeValue ?? "").length;

    if (tn === range.startContainer) s = range.startOffset;
    if (tn === range.endContainer) e = range.endOffset;

    // If selection starts/ends in element nodes, we won't have exact matches here.
    // Keep simple: clamp and wrap entire text nodes if not exact.
    if (range.startContainer.nodeType !== Node.TEXT_NODE && textNodes[0] === tn) s = 0;
    if (range.endContainer.nodeType !== Node.TEXT_NODE && textNodes[textNodes.length - 1] === tn) e = (tn.nodeValue ?? "").length;

    const mark = wrapTextSegment(tn, s, e, noteId);
    if (mark) marks.push(mark);
  }
  return marks;
}
// 从存储中获取所有笔记
async function getAllNotes() {
  const data = await chrome.storage.local.get({ [STORAGE_KEY]: [] });
  return Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
}
// 将所有笔记保存到存储中
async function setAllNotes(notes) {
  await chrome.storage.local.set({ [STORAGE_KEY]: notes });
}
// 规范化URL以便比较
function normalizeUrl(u) {
  try {
    const url = new URL(u);
    // normalize fragment away; notes are page-based
    url.hash = "";
    return url.toString();
  } catch { return u; }
}
// 比较两个URL是否指向同一页面
function samePageUrl(a, b) {
  return normalizeUrl(a) === normalizeUrl(b);
}
// 添加笔记并高亮选中文本
async function addNoteFromSelection(fallbackText = "", fallbackUrl = "") {
  const sel = window.getSelection();
  let range = null;

  if (sel && sel.rangeCount > 0) {
    range = sel.getRangeAt(0);
  }

  const selected = (range ? range.toString() : fallbackText).trim();
  if (!selected) {
    showToast("未检测到选中文本");
    return;
  }
  if (range && isExcludedNode(range.commonAncestorContainer)) return;

  const id = randomId();
  // Apply highlight if we still have a DOM range
  if (range) {
    highlightRange(range, id);
    try { sel.removeAllRanges(); } catch {}
  }

  const ts = nowTs();

  const note = {
    id,
    title: document.title || "Untitled",
    quote: selected,
    comment: "",
    url: fallbackUrl || location.href,
    createdAt: ts,
    dateKey: dateKeyFromTs(ts),
    selector: range ? getDomSelector(range) : null,
  };

  const notes = await getAllNotes();
  notes.unshift(note);
  await setAllNotes(notes);
  showToast(range ? "已保存并高亮" : "已保存（未能高亮）");
}
// 在页面上查找与给定精确文本匹配的范围
function findTextOccurrence(exact) {
  if (!exact) return null;
  const needle = exact.trim();
  if (!needle) return null;

  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        if (isExcludedNode(node)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );

  let node;
  while ((node = walker.nextNode())) {
    const hay = node.nodeValue;
    const idx = hay.indexOf(needle);
    if (idx !== -1) {
      const r = document.createRange();
      r.setStart(node, idx);
      r.setEnd(node, idx + needle.length);
      return r;
    }
  }
  return null;
}
// 移除页面上不在允许ID列表中的高亮
function removeMarksNotIn(allowedIds) {
  const marks = Array.from(document.querySelectorAll("mark.webnotes-mark[data-webnotes-id]"));
  for (const m of marks) {
    const id = m.dataset.webnotesId;
    if (!allowedIds.has(id)) {
      // unwrap
      const parent = m.parentNode;
      if (!parent) continue;
      parent.replaceChild(document.createTextNode(m.textContent ?? ""), m);
      parent.normalize();
    }
  }
}
// 为当前页面应用所有相关笔记的高亮
async function applyHighlightsForThisPage() {
  const notes = await getAllNotes();
  const pageNotes = notes.filter(n => samePageUrl(n.url, location.href));
  const allowed = new Set(pageNotes.map(n => n.id));

  // Remove outdated marks
  removeMarksNotIn(allowed);

  // Apply missing marks
  const existing = new Set(
    Array.from(document.querySelectorAll("mark.webnotes-mark[data-webnotes-id]"))
      .map(m => m.dataset.webnotesId)
  );

  for (const note of pageNotes) {
    if (existing.has(note.id)) continue;

    // Try DOM selector first
    const sel = note.selector;
    let range = null;
    if (sel?.startXPath && sel?.endXPath && sel.startTextIndex >= 0 && sel.endTextIndex >= 0) {
      const startNode = resolveTextNode(sel.startXPath, sel.startTextIndex);
      const endNode   = resolveTextNode(sel.endXPath, sel.endTextIndex);
      if (startNode && endNode) {
        try {
          const r = document.createRange();
          r.setStart(startNode, Math.min(sel.startOffset ?? 0, (startNode.nodeValue ?? "").length));
          r.setEnd(endNode, Math.min(sel.endOffset ?? 0, (endNode.nodeValue ?? "").length));
          if (r.toString().trim() === (sel.exact ?? "").trim()) range = r;
        } catch {}
      }
    }

    // Fallback: text search
    if (!range) range = findTextOccurrence(note.quote);

    if (range) highlightRange(range, note.id);
  }
}

// 监听来自后台脚本的消息以添加笔记
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "WEBNOTES_ADD_NOTE") {
    addNoteFromSelection(msg.selectionText || "", msg.pageUrl || "");
  }
});

// 监听存储变化以保持高亮同步
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (!changes[STORAGE_KEY]) return;
  applyHighlightsForThisPage();
});

// 支持跳转到特定笔记
async function jumpIfRequested(){
  try{
    const u = new URL(location.href);
    const noteId = u.searchParams.get("__webnotes_jump");
    if (!noteId) return;

    const maxTries = 24;
    let tries = 0;

    const tick = () => {
      tries++;
      const el = document.querySelector(`mark.webnotes-mark[data-webnotes-id="${CSS.escape(noteId)}"]`);
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        // Flash to help user see it
        el.classList.add("webnotes-mark--focus");
        setTimeout(() => el.classList.remove("webnotes-mark--focus"), 1400);

        // Clean URL (remove param) to avoid re-jump on reload
        try{
          const u2 = new URL(location.href);
          u2.searchParams.delete("__webnotes_jump");
          history.replaceState({}, "", u2.toString());
        }catch{}
        return;
      }
      if (tries < maxTries) setTimeout(tick, 120);
    };

    tick();
  }catch{}
}

applyHighlightsForThisPage().then(jumpIfRequested);
