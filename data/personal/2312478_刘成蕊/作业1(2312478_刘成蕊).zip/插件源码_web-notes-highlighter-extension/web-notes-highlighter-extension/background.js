const MENU_ID = "webnotes_add_note";
// 创建右键菜单
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: "加入笔记（Web Notes）",
    contexts: ["selection"],
  });
});
// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab?.id) return;

  const frameId = typeof info.frameId === "number" ? info.frameId : 0;

  try {
    await chrome.tabs.sendMessage(
      tab.id,
      {
        type: "WEBNOTES_ADD_NOTE",
        selectionText: info.selectionText || "",
        pageUrl: info.pageUrl || tab.url || "",
      },
      { frameId }
    );
  } catch (e) {
    console.warn("WEBNOTES sendMessage failed:", e);
  }
});

// 监听来自内容脚本的消息，打开笔记页面
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "WEBNOTES_OPEN_PAGE") {
    chrome.tabs.create({ url: chrome.runtime.getURL("notes.html") });
  }
});
