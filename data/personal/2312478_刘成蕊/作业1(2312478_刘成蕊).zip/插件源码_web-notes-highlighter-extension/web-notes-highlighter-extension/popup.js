document.getElementById("open").addEventListener("click", async () => {
  // 打开笔记页面
  chrome.runtime.sendMessage({ type: "WEBNOTES_OPEN_PAGE" });
});
