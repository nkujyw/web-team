const ALARM_NAME = 'simple-alarm';

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tabId = tabs[0]?.id;

  if (tabId) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => alert('⏰ 时间到！')
      });
    } catch (e) {}
  }

  await chrome.storage.local.remove(['alarmTargetAt','durationSec']);
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.clear(ALARM_NAME);
});
