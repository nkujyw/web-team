const ALARM_NAME = 'simple-alarm';
const pad = n => String(n).padStart(2, '0');

async function refreshStatus(){
  const { alarmTargetAt, durationSec } = await chrome.storage.local.get(['alarmTargetAt','durationSec']);
  const out = document.getElementById('status');
  if (!alarmTargetAt){ out.textContent = '未设置计时。'; return; }
  const leftMs = alarmTargetAt - Date.now();
  if (leftMs <= 0){ out.textContent = '计时已到。'; return; }
  const s = Math.ceil(leftMs/1000), m = Math.floor(s/60), ss = s%60;
  out.textContent = `剩余 ${pad(m)}:${pad(ss)}（总 ${Math.floor((durationSec||0)/60)}分${(durationSec||0)%60}秒）`;
}

async function startTimer(totalSec){
  if (!Number.isFinite(totalSec) || totalSec <= 0){
    document.getElementById('status').textContent = '请输入大于 0 的时间。';
    return;
  }
  const minDelay = 6;                      // Chrome/Edge alarms 最小约 0.1 分钟 ≈ 6 秒
  if (totalSec < minDelay) totalSec = minDelay;

  const delayInMinutes = totalSec / 60;
  const targetAt = Date.now() + totalSec * 1000;

  await chrome.storage.local.set({ alarmTargetAt: targetAt, durationSec: totalSec });
  await chrome.alarms.clear(ALARM_NAME);
  chrome.alarms.create(ALARM_NAME, { delayInMinutes });

  document.getElementById('status').textContent = '计时已启动…';
  refreshStatus();
}

document.getElementById('start').addEventListener('click', async () => {
  const m = parseInt(document.getElementById('min').value || '0', 10);
  const s = parseInt(document.getElementById('sec').value || '0', 10);
  startTimer(m*60 + s);
});

document.getElementById('cancel').addEventListener('click', async () => {
  await chrome.alarms.clear(ALARM_NAME);
  await chrome.storage.local.remove(['alarmTargetAt','durationSec']);
  document.getElementById('status').textContent = '已取消。';
});

document.querySelectorAll('.chip').forEach(el=>{
  el.addEventListener('click', ()=>{
    const sec = parseInt(el.dataset.sec, 10);
    document.getElementById('min').value = Math.floor(sec/60);
    document.getElementById('sec').value = sec%60;
    startTimer(sec);
  });
});

refreshStatus();
setInterval(refreshStatus, 1000);
