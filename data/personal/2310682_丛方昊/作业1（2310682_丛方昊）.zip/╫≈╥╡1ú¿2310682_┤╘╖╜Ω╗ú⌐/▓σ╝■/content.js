let readingModeEnabled = false;
const originalStates = new Map();
let mainContentEl = null;

const AD_SELECTORS = [
    '.advertisement', '.ads', '.ad-container', '.banner-ad', '.google-ad',
    '.popup', '.modal', '.lightbox', 'iframe[src*="ad"]', '[style*="fixed"]',
    '[class*="sidebar"]', '[id*="sidebar"]', '.sidebar', '.side-bar', '[class*="side"]', '.side-nav', '.side-content',
    '[class*="widget"]', '.widget-area', '.secondary',
    '[class*="mobile"]', '[class*="phone"]', '[class*="float"]',
    '[class*="recommend"]', '[class*="guess"]', '[class*="suggest"]', '[class*="like"]', '[class*="hot"]', '[class*="popular"]',
    '.recommend', '.guess-you-like', '.suggest', '.hot-news', '.popular-articles', '.mobile-read', '.phone-float',
    '.shopping-recommend', '.shopping-ad', '.product-recommend', '.buy-recommend'
];

const RECOMMENDATION_KEYWORDS = ['猜你喜欢', '为你推荐', '热门推荐', '相关推荐', '小编推荐', '手机阅读', '悬浮', '推荐', '热门', '精选', '购物推荐', '商品推荐', '买了还买', '看了还看'];

async function saveState(enabled) {
    await chrome.storage.local.set({ readingModeEnabled: enabled });
}

async function loadState() {
    return chrome.storage.local.get(['readingModeEnabled']);
}

const textLen = el => (el.textContent || '').replace(/\s+/g, ' ').trim().length;

function findMainContent() {
    const candidates = document.querySelectorAll('div, article, main, section, .content, .article, .post-content');
    let bestCandidate = null;
    let maxLength = 500;
    
    candidates.forEach(el => {
        const length = textLen(el);
        const isSidebar = el.className?.toLowerCase().includes('sidebar') || el.id?.toLowerCase().includes('sidebar');
        const isNav = el.tagName === 'NAV' || el.className?.toLowerCase().includes('nav');
        
        if (length > maxLength && !isSidebar && !isNav) {
            bestCandidate = el;
            maxLength = length;
        }
    });
    
    return bestCandidate;
}

function hideElement(el) {
    if (!originalStates.has(el)) {
        originalStates.set(el, {
            display: el.style.display,
            visibility: el.style.visibility
        });
    }
    el.style.setProperty('display', 'none', 'important');
}

function restoreElement(el) {
    const state = originalStates.get(el);
    if (state) {
        el.style.display = state.display || '';
        el.style.visibility = state.visibility || '';
    }
}

function filterNonContent() {
    AD_SELECTORS.forEach(selector => {
        document.querySelectorAll(selector).forEach(el => {
            if (el === mainContentEl || el.contains(mainContentEl)) return;
            
            let parent = el.parentElement;
            let isInsideMainContent = false;
            while (parent && parent !== document.body) {
                if (parent === mainContentEl) {
                    isInsideMainContent = true;
                    break;
                }
                parent = parent.parentElement;
            }
            
            if (!isInsideMainContent) {
                hideElement(el);
            }
        });
    });
    
    if (mainContentEl) {
        filterRecommendationsInContent(mainContentEl);
    }
}

function filterRecommendationsInContent(contentEl) {
    const recommendationSelectors = [
        '[class*="recommend"]', '[class*="guess"]', '[class*="suggest"]', '[class*="like"]', '[class*="hot"]', '[class*="popular"]',
        '[id*="recommend"]', '[id*="guess"]', '[id*="suggest"]', '[id*="like"]', '[id*="hot"]', '[id*="popular"]',
        '.recommend', '.guess', '.suggest', '.like', '.hot', '.popular', '.mobile-read', '.phone-float', '.float-ad',
        '.shopping', '.product', '.buy', '.purchase', '.shopping-recommend', '.shopping-ad', '.product-recommend', '.buy-recommend'
    ];
    
    recommendationSelectors.forEach(selector => {
        contentEl.querySelectorAll(selector).forEach(el => {
            if (el !== contentEl && contentEl.contains(el)) {
                hideElement(el);
            }
        });
    });
    
    const allElements = contentEl.querySelectorAll('div, section, article, aside, .module, .widget');
    allElements.forEach(el => {
        const text = el.textContent?.trim() || '';
        if (text && RECOMMENDATION_KEYWORDS.some(keyword => text.includes(keyword))) {
            const rect = el.getBoundingClientRect();
            if (rect.height < 500 && rect.width < 500) {
                hideElement(el);
            }
        }
    });
    
    const floatingElements = contentEl.querySelectorAll('*');
    floatingElements.forEach(el => {
        const style = window.getComputedStyle(el);
        if (style.position === 'fixed' || style.position === 'absolute') {
            const rect = el.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0 && rect.height < 200 && rect.width < 300) {
                hideElement(el);
            }
        }
    });
}

function applyReadingStyles() {
    if (mainContentEl) {
        if (!originalStates.has(mainContentEl)) {
            originalStates.set(mainContentEl, {
                background: mainContentEl.style.background,
                padding: mainContentEl.style.padding,
                borderRadius: mainContentEl.style.borderRadius,
                boxShadow: mainContentEl.style.boxShadow,
                maxWidth: mainContentEl.style.maxWidth,
                margin: mainContentEl.style.margin
            });
        }
        
        mainContentEl.style.background = '#f8f9fa';
        mainContentEl.style.padding = '20px';
        mainContentEl.style.borderRadius = '8px';
        mainContentEl.style.boxShadow = '0 2px 10px rgba(0,0,0,.1)';
        mainContentEl.style.maxWidth = '800px';
        mainContentEl.style.margin = '20px auto';
    }
}

function clearReadingStyles() {
    if (mainContentEl) {
        const state = originalStates.get(mainContentEl);
        if (state) {
            mainContentEl.style.background = state.background || '';
            mainContentEl.style.padding = state.padding || '';
            mainContentEl.style.borderRadius = state.borderRadius || '';
            mainContentEl.style.boxShadow = state.boxShadow || '';
            mainContentEl.style.maxWidth = state.maxWidth || '';
            mainContentEl.style.margin = state.margin || '';
        }
    }
}

async function enable() {
    if (readingModeEnabled) return;
    
    mainContentEl = findMainContent();
    if (!mainContentEl) return false;

    if (!originalStates.has(document.body)) {
        originalStates.set(document.body, {
            style: document.body.style.cssText,
            className: document.body.className
        });
    }

    filterNonContent();
    applyReadingStyles();
    readingModeEnabled = true;
    await saveState(true);
    
    return true;
}

async function disable() {
    if (!readingModeEnabled) return;
    
    const bodyState = originalStates.get(document.body);
    if (bodyState) {
        document.body.style.cssText = bodyState.style;
        document.body.className = bodyState.className;
    }
    
    clearReadingStyles();

    originalStates.forEach((state, el) => {
        if (el !== document.body && el !== mainContentEl) {
            restoreElement(el);
        }
    });

    readingModeEnabled = false;
    mainContentEl = null;
    await saveState(false);
}

async function toggle() {
    return readingModeEnabled ? 
        (await disable(), false) : 
        (await enable(), true);
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    (async () => {
        if (req.action === 'toggleReadingMode') {
            const enabled = await toggle();
            sendResponse({ enabled });
        } else if (req.action === 'getStatus') {
            sendResponse({ enabled: readingModeEnabled });
        }
    })();
    return true;
});

(async () => {
    const state = await loadState();
    if (state.readingModeEnabled) {
        setTimeout(async () => {
            await enable();
        }, 300);
    }
})();

let lastUrl = location.href;
new MutationObserver(() => {
    if (location.href !== lastUrl) {
        lastUrl = location.href;
        
        readingModeEnabled = false;
        mainContentEl = null;
        originalStates.clear();
        
        setTimeout(async () => {
            const state = await loadState();
            if (state.readingModeEnabled) {
                await enable();
            }
        }, 500);
    }
}).observe(document, { subtree: true, childList: true });

const dynamicContentObserver = new MutationObserver((mutations) => {
    if (readingModeEnabled) {
        let shouldRefilter = false;
        
        mutations.forEach((mutation) => {
            if (mutation.addedNodes.length > 0) {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) {
                        shouldRefilter = true;
                    }
                });
            }
        });
        
        if (shouldRefilter) {
            setTimeout(() => {
                filterNonContent();
            }, 100);
        }
    }
});

dynamicContentObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: false,
    characterData: false
});