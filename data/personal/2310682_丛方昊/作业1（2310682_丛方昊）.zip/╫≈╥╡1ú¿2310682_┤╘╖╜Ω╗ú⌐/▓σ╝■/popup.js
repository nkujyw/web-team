document.addEventListener('DOMContentLoaded', function() {
    const toggleButton = document.getElementById('toggleReading');
    
    initializeUIState();
    
    async function initializeUIState() {
        const result = await chrome.storage.local.get(['readingModeEnabled']);
        updateButtonState(result.readingModeEnabled || false);
    }
    
    function updateButtonState(enabled) {
        toggleButton.textContent = enabled ? '退出阅读模式' : '切换阅读模式';
        toggleButton.classList.toggle('success', enabled);
    }
    
    toggleButton.addEventListener('click', async () => {
        const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
        
        const response = await chrome.tabs.sendMessage(tab.id, {
            action: "toggleReadingMode"
        });
        
        updateButtonState(response.enabled);
    });
});