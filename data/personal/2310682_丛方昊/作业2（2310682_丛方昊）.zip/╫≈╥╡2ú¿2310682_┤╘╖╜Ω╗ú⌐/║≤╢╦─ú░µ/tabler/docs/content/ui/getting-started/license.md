---
title: Tabler License
summary: The MIT license grants you the flexibility to use Tabler in commercial or personal projects, modify its code, and distribute it freely. Ensure you include the required license and copyright notices to stay compliant with the terms.
description: "Tabler's MIT license: freedom to use, modify, and share."
---

Tabler is an open-source project licensed under the **MIT license**, giving you extensive freedom to use, modify, and distribute the software. This license ensures that you can adapt Tabler to your needs while maintaining the required attributions. While attribution is not required, it is greatly appreciated to acknowledge the hard work of the developers.

## What You Can Do with Tabler

The MIT license allows you to:
- Use Tabler in **commercial projects**.
- Use Tabler in **personal or private projects**.
- **Modify and customize** the source code to fit your requirements.
- **Distribute** the original or modified code.
- **Sublicense**: Integrate Tabler into projects with a more restrictive license.

## What You Cannot Do with Tabler

- The software is provided **“as is”**, meaning you cannot hold the authors or contributors liable for any issues, bugs, or damages that may arise from its use.

## What You Must Do When Using Tabler

When using Tabler, you must:
1. Include the **license notice** in all copies of the work.
2. Include the **copyright notice** in all copies of the work, except for the footer of the example HTML pages provided in the repository.

For more details, please refer to the full [Tabler License](https://github.com/tabler/tabler/blob/main/LICENSE).

By adhering to these requirements, you help ensure the continued openness and usability of Tabler for everyone. Thank you for supporting open-source software!