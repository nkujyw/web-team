---
title: FAQ
summary: Answers to the most frequently asked questions.
description: Common questions and answers.
order: 12
---

## I found an issue, what can I do?

If you think you have found an issue that can only be fixed by the maintainers, feel free to open an issue on [GitHub](https://github.com/tabler/tabler).

## Will there be a version for Vue or React?

We are evaluating adding support for Vue 3 and React to all of our components, but it is not a top priority at the moment.

## Can I use Tabler in open source projects?

Yes, absolutely.

## Can I use Tabler in commercial projects?

Of course! Tabler is under MIT license, so you can confidently use it in commercial projects. However, remember to include a note that your project uses Tabler. You can read about our license here: [License]({{ site.homepage }}/license).

## Can Tabler be used with WordPress?

Tabler is an HTML template that can be used for any purpose. However, it is not made to be easily installed on WordPress. It will require some effort and enough knowledge of the WordPress script to do so.

## How do I get notified of new Tabler versions?

You may watch [the releases on GitHub](https://github.com/tabler/tabler/releases), follow us on [X](https://x.com/tabler_io) or stay up to date with our [changelog]({{ site.homepage }}/changelog).
