---
title: Forms
order: 5
description: Build and manage web forms.
summary: The forms section provides a collection of components and tools for creating user-friendly and accessible forms, enhancing user interaction and improving data collection.
---