---
title: EPS version
description: Download Tabler Icons in EPS format.	
---

![](/img/icons/package-eps.png)


## Installation

{% include "docs/tabs-package.html" name="@tabler/icons-eps" %}

or just [download from Github](https://github.com/tabler/tabler-icons/releases).

All EPS files are stored in `icons` subdirectory.
