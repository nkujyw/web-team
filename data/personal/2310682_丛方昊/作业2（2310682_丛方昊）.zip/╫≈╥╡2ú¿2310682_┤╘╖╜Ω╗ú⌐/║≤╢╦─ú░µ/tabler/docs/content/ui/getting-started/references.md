---
title: 3rd-party Libraries & Resources
---

Tabler uses the following open source resources:

{% include "docs/open-source-resources.html" %}
