import docsearch from '@docsearch/js';

docsearch({
	container: '#docsearch',
	appId: "NE1EGTYLS9",
	indexName: "tabler",
	apiKey: "016353235ef1dd32a6c392be0e939058",
});
