---
"@tabler/preview": patch
---

Added comprehensive All Elements page with all UI components and Bootstrap elements
