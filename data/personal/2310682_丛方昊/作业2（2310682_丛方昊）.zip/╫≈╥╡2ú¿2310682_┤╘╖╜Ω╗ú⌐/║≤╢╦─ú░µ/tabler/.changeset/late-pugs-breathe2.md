---
"@tabler/core": patch
"@tabler/preview": patch
---

Added `bg-blur` utility and increased `container-tight` width for layout flexibility.
