---
"@tabler/core": patch
---

Fixed `.btn-icon` to be square by aligning `min-width` calculation with base `.btn` formula.
