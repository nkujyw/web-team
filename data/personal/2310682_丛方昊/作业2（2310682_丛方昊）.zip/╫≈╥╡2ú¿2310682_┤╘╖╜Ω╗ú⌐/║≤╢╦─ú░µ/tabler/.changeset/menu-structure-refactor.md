---
"@tabler/preview": minor
---

Refactored page-menu structure for dashboards and updated navigation menu organization.

