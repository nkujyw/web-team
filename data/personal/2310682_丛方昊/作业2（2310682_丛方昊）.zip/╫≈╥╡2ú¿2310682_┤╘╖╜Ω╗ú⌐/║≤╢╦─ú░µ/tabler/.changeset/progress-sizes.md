---
"@tabler/core": minor
---

Added `.progress-lg` and `.progress-xl` size variants for the progress component.
