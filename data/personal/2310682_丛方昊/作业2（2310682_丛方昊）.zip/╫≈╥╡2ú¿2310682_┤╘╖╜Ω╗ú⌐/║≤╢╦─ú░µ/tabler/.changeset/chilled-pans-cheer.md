---
"@tabler/preview": minor
---

Added color palette to signing component.
