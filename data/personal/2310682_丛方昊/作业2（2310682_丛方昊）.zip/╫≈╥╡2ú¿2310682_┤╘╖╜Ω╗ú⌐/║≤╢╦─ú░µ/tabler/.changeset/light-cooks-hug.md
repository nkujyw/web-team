---
"@tabler/preview": patch
---

Updated icons to v3.34.1 with 75 new icons.
