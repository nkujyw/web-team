---
"@tabler/core": patch
---

Updated Bootstrap to v5.3.8.
