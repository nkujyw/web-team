---
"@tabler/core": patch
---

Update SCSS to use logical properties
