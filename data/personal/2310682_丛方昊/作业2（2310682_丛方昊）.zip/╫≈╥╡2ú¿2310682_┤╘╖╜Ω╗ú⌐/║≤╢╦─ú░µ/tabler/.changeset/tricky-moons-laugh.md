---
"@tabler/docs": patch
---

Fixed Docs search display in dark mode.
