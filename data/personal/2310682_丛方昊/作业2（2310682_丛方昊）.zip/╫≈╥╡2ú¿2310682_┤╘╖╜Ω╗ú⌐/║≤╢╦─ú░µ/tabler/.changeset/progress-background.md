---
"@tabler/core": minor
"@tabler/preview": minor
---

Added Progress Background component with text labels and value display.
