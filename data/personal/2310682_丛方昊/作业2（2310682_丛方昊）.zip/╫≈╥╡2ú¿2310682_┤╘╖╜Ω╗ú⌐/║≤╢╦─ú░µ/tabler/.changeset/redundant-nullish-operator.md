---
"@tabler/core": patch
---

Removed redundant nullish coalescing operator from `html` option in popover and tooltip initialization.

