---
"@tabler/preview": minor
---

Added new Crypto Dashboard page with cryptocurrency portfolio overview, market data, and order history.

