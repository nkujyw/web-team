---
"@tabler/core": patch
---

Updated `stroke-width` for `.icon-sm` from `1` to `1.5` for better visibility.
