---
"@tabler/core": minor
"@tabler/docs": patch
---

Added Geist font family integration.

