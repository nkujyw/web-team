---
"@tabler/preview": patch
---

Update Tabler Icons to v3.35.0
