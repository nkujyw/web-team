---
"@tabler/preview": patch
---

Updated activity messages.
