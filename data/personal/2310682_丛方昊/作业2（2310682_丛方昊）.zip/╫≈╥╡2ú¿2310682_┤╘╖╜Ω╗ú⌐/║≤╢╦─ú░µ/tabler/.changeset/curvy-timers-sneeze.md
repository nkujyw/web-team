---
"@tabler/core": patch
---

Fixed icon alignment for `.btn-sm` and `.btn-xl` sizes.
