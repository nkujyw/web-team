---
"@tabler/core": patch
---

Fixed mixed declarations in SCSS.
