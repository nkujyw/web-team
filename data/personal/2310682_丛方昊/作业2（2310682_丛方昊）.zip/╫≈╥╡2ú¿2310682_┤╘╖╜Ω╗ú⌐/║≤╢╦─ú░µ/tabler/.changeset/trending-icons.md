---
"@tabler/core": patch
"@tabler/preview": patch
---

Updated trending component to use `arrow-up`/`arrow-down` instead of `trending-up`/`trending-down`.
