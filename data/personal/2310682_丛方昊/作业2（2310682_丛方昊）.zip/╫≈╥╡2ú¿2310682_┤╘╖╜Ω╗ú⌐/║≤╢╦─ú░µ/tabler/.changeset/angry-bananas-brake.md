---
"@tabler/core": minor
"@tabler/preview": minor
---

Added Pay page with dedicated layout, navigation link, and card/PayPal payment form.
