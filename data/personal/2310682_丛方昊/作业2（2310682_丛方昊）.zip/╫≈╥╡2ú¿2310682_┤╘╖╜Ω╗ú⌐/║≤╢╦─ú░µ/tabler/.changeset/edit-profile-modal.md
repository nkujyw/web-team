---
"@tabler/preview": minor
---

Added Edit Profile modal with avatar upload, personal information fields, social links, and date of birth.

