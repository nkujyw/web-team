---
"@tabler/core": minor
---

Added `.btn-ghost` button variant with transparent background and hover effects.
