---
"@tabler/core": patch
---

Fixed `.input-icon-addon` z-index issue with form validation feedback and added default height.
