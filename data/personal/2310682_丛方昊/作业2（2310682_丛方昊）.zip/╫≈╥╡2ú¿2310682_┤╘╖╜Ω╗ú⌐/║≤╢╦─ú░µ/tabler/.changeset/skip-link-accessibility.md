---
"@tabler/core": patch
---

Updated skip-link to use `visually-hidden` for improved accessibility.
