---
"@tabler/core": minor
"@tabler/preview": minor
---

Added Progress Steps component for step-by-step navigation indicators.
