---
"@tabler/preview": minor
---

Added New Task modal with fields for task name, description, assigned user, priority, due date, and category tags.

