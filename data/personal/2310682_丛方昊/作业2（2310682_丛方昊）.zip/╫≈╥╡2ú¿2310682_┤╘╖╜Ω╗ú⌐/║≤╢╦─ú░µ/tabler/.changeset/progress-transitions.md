---
"@tabler/core": patch
---

Added smooth transitions for progress bar `width` and `background-color` changes.
