---
"@tabler/core": patch
---

Added `media-print` mixin and print styles to hide interactive components during printing.
