---
"@tabler/core": patch
---

Fixed double bottom border in tables.
