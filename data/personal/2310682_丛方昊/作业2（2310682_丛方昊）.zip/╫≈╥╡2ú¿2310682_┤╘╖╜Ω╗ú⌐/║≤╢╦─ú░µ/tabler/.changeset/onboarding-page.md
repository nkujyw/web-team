---
"@tabler/preview": minor
---

Added new onboarding page with progress indicator and navigation layout.
