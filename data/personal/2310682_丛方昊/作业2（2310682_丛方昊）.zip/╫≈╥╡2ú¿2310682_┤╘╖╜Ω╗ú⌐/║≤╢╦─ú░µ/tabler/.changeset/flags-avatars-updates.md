---
"@tabler/core": patch
---

Updated flags and avatars styling for better visual consistency.

