---
"@tabler/core": minor
"@tabler/preview": minor
---

Added language selector dropdown to navbar with flag indicators for multilingual support.
