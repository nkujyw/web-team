---
"@tabler/preview": patch
---

Fixed responsive layouts on the Form Elements page.
