---
"@tabler/preview": minor
---

Added Change Password modal with current password, new password with strength indicator, confirm password validation, and show/hide password toggles.

