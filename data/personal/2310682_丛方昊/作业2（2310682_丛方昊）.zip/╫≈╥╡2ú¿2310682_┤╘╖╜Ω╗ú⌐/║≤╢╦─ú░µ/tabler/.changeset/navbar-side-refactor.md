---
"@tabler/core": minor
"@tabler/preview": minor
---

Refactored navbar-side component by consolidating separate include files (apps, language, notifications, theme, user) into a single `navbar-side.html` file for better maintainability.

